import { useState, useEffect } from 'react';
import { 
  Crown, Coins, Key, MessageCircle, ChevronRight, 
  Zap, Shield, Headphones, Ban, ShoppingCart, Sparkles 
} from 'lucide-react';
import { Sidebar } from './components/Sidebar';
import { RankModal } from './components/RankModal';
import './App.css';

// Rank data
const ranks = [
  { name: 'PRO', price: '19Rs', image: '/images/rank-pro.jpg', color: '#FF5555' },
  { name: 'MVP', price: '29Rs', image: '/images/rank-mvp.jpg', color: '#55FFFF' },
  { name: 'VIP', price: '69Rs', image: '/images/rank-vip.jpg', color: '#55FF55' },
  { name: 'ELITE', price: '99Rs', image: '/images/rank-elite.jpg', color: '#FF55FF' },
  { name: 'IMMORTAL', price: '149Rs', image: '/images/rank-immortal.jpg', color: '#AA00AA' },
];

// Coins data
const coins = [
  { amount: '100', price: '29Rs', popular: false },
  { amount: '200', price: '69Rs', popular: false },
  { amount: '300', price: '89Rs', popular: false },
  { amount: '400', price: '100Rs', popular: true },
  { amount: '500', price: '199Rs', popular: false },
  { amount: '1000', price: '399Rs', popular: true },
];

// Keys data
const keys = [
  { name: 'Vote Key', price: '19Rs', image: '/images/keys-crate.jpg' },
  { name: 'Prime Key', price: '49Rs', image: '/images/keys-crate.jpg' },
  { name: 'Omega Key', price: '89Rs', image: '/images/keys-crate.jpg' },
  { name: 'Epic Key', price: '120Rs', image: '/images/keys-crate.jpg' },
];

function App() {
  const [activeSection, setActiveSection] = useState('home');
  const [selectedRank, setSelectedRank] = useState<typeof ranks[0] | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isVisible, setIsVisible] = useState<Record<string, boolean>>({});

  // Intersection Observer for scroll animations
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          const id = entry.target.getAttribute('id') || '';
          if (entry.isIntersecting) {
            setIsVisible((prev) => ({ ...prev, [id]: true }));
            setActiveSection(id);
          }
        });
      },
      { threshold: 0.3, rootMargin: '-10% 0px -10% 0px' }
    );

    document.querySelectorAll('section[id]').forEach((section) => {
      observer.observe(section);
    });

    return () => observer.disconnect();
  }, []);

  const openRankModal = (rank: typeof ranks[0]) => {
    setSelectedRank(rank);
    setIsModalOpen(true);
  };

  const closeRankModal = () => {
    setIsModalOpen(false);
    setTimeout(() => setSelectedRank(null), 200);
  };

  return (
    <div className="min-h-screen bg-angel-dark text-angel-text">
      {/* Grain overlay */}
      <div className="grain-overlay" />

      {/* Sidebar */}
      <Sidebar activeSection={activeSection} />

      {/* Main content */}
      <main className="lg:ml-[260px]">
        {/* Home Section */}
        <section 
          id="home" 
          className="min-h-screen flex items-center justify-center px-4 sm:px-6 lg:px-12 py-20 lg:py-0 relative overflow-hidden"
        >
          {/* Background effects */}
          <div className="absolute inset-0 bg-dot-pattern opacity-50" />
          <div className="absolute top-1/4 left-1/4 w-64 h-64 bg-angel-accent/5 rounded-full blur-3xl" />
          <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-angel-accent/3 rounded-full blur-3xl" />

          <div 
            className={`relative z-10 max-w-6xl w-full transition-all duration-1000 ${
              isVisible['home'] ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
            }`}
          >
            {/* Hero Card */}
            <div className="bg-angel-card border border-angel-border rounded-3xl overflow-hidden shadow-card">
              <div className="grid lg:grid-cols-2 gap-0">
                {/* Image */}
                <div className="relative h-64 lg:h-auto">
                  <img 
                    src="/images/hero-character.jpg" 
                    alt="Angel Store Hero"
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-r from-transparent to-angel-card/80 lg:block hidden" />
                  <div className="absolute inset-0 bg-gradient-to-t from-angel-card to-transparent lg:hidden" />
                </div>

                {/* Content */}
                <div className="p-8 lg:p-12 flex flex-col justify-center">
                  <div className="flex items-center gap-2 mb-4">
                    <Sparkles className="w-5 h-5 text-angel-accent" />
                    <span className="font-pixel text-angel-accent text-lg">Premium Minecraft Store</span>
                  </div>
                  
                  <h1 className="font-display text-4xl lg:text-6xl font-bold mb-4 leading-tight">
                    Angel <span className="text-angel-accent">Store</span>
                  </h1>
                  
                  <p className="text-angel-muted text-lg mb-6 leading-relaxed">
                    Welcome to Angel Store, your ultimate destination for premium Minecraft server items. 
                    We offer high-quality Ranks, Coins, and Keys designed to enhance your gameplay experience.
                  </p>
                  
                  <p className="text-angel-text mb-8">
                    Upgrade your adventure, unlock exclusive features, and become part of something greater.
                  </p>

                  <div className="flex flex-wrap gap-4">
                    <a 
                      href="#ranks"
                      className="btn-primary inline-flex items-center gap-2"
                    >
                      <Crown className="w-5 h-5" />
                      Explore Ranks
                      <ChevronRight className="w-4 h-4" />
                    </a>
                    <a 
                      href="https://discord.gg/y4HZq97hgW"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="px-6 py-3 rounded-xl border border-white/10 text-angel-text hover:bg-white/5 transition-colors inline-flex items-center gap-2"
                    >
                      <MessageCircle className="w-5 h-5" />
                      Join Discord
                    </a>
                  </div>

                  <div className="mt-8 flex items-center gap-6 text-sm text-angel-muted">
                    <span className="flex items-center gap-2">
                      <Zap className="w-4 h-4 text-angel-accent" />
                      Fast Delivery
                    </span>
                    <span className="flex items-center gap-2">
                      <Shield className="w-4 h-4 text-angel-accent" />
                      Secure Checkout
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Ranks Section */}
        <section 
          id="ranks" 
          className="min-h-screen px-4 sm:px-6 lg:px-12 py-20 lg:py-24 relative"
        >
          <div className="absolute inset-0 bg-line-pattern opacity-30" />
          
          <div className="relative z-10 max-w-7xl mx-auto">
            {/* Section Header */}
            <div 
              className={`mb-12 transition-all duration-700 ${
                isVisible['ranks'] ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
              }`}
            >
              <div className="flex items-center gap-3 mb-4">
                <Crown className="w-6 h-6 text-angel-accent" />
                <span className="font-pixel text-angel-accent text-lg">RANKS</span>
              </div>
              <h2 className="font-display text-3xl lg:text-5xl font-bold mb-4">
                Choose Your <span className="text-angel-accent">Rank</span>
              </h2>
              <p className="text-angel-muted text-lg max-w-2xl">
                Unlock exclusive perks, kits, and commands. Each rank offers unique benefits to enhance your gameplay.
              </p>
            </div>

            {/* Rank Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4 lg:gap-6">
              {ranks.map((rank, index) => (
                <div
                  key={rank.name}
                  onClick={() => openRankModal(rank)}
                  className={`rank-card cursor-pointer group transition-all duration-500 ${
                    isVisible['ranks'] 
                      ? 'opacity-100 translate-y-0' 
                      : 'opacity-0 translate-y-10'
                  }`}
                  style={{ 
                    transitionDelay: `${index * 100}ms`,
                    borderColor: `${rank.color}30`
                  }}
                >
                  {/* Image */}
                  <div className="relative h-48 overflow-hidden">
                    <img 
                      src={rank.image} 
                      alt={rank.name}
                      className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                    />
                    <div 
                      className="absolute inset-0 opacity-0 group-hover:opacity-30 transition-opacity duration-300"
                      style={{ backgroundColor: rank.color }}
                    />
                  </div>

                  {/* Content */}
                  <div className="p-4">
                    <h3 
                      className="font-display text-xl font-bold mb-1"
                      style={{ color: rank.color }}
                    >
                      {rank.name}
                    </h3>
                    <p className="font-pixel text-lg text-angel-muted">{rank.price}</p>
                  </div>

                  {/* Hover glow */}
                  <div 
                    className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none rounded-2xl"
                    style={{ 
                      boxShadow: `inset 0 0 30px ${rank.color}20`,
                    }}
                  />
                </div>
              ))}
            </div>

            {/* Note */}
            <div 
              className={`mt-12 text-center transition-all duration-700 delay-500 ${
                isVisible['ranks'] ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
              }`}
            >
              <p className="text-angel-muted">
                Click on any rank to view detailed perks and benefits
              </p>
            </div>
          </div>
        </section>

        {/* Coins Section */}
        <section 
          id="coins" 
          className="min-h-screen px-4 sm:px-6 lg:px-12 py-20 lg:py-24 relative"
        >
          <div className="absolute inset-0 bg-dot-pattern opacity-30" />
          
          <div className="relative z-10 max-w-7xl mx-auto">
            {/* Section Header */}
            <div 
              className={`mb-12 transition-all duration-700 ${
                isVisible['coins'] ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
              }`}
            >
              <div className="flex items-center gap-3 mb-4">
                <Coins className="w-6 h-6 text-angel-accent" />
                <span className="font-pixel text-angel-accent text-lg">COINS</span>
              </div>
              <h2 className="font-display text-3xl lg:text-5xl font-bold mb-4">
                Buy <span className="text-angel-accent">Coins</span>
              </h2>
              <p className="text-angel-muted text-lg max-w-2xl">
                Purchase in-game currency to spend on crates, repairs, and upgrades.
              </p>
            </div>

            {/* Coins Cards */}
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4 lg:gap-6">
              {coins.map((coin, index) => (
                <div
                  key={coin.amount}
                  className={`rank-card relative overflow-hidden transition-all duration-500 ${
                    isVisible['coins'] 
                      ? 'opacity-100 translate-y-0' 
                      : 'opacity-0 translate-y-10'
                  } ${coin.popular ? 'border-angel-accent/50' : ''}`}
                  style={{ transitionDelay: `${index * 80}ms` }}
                >
                  {/* Popular badge */}
                  {coin.popular && (
                    <div className="absolute top-3 right-3 z-10">
                      <span className="bg-angel-accent text-angel-dark text-xs font-bold px-2 py-1 rounded-full">
                        BEST
                      </span>
                    </div>
                  )}

                  {/* Image */}
                  <div className="relative h-32 overflow-hidden">
                    <img 
                      src="/images/coins-stack.jpg" 
                      alt={`${coin.amount} Coins`}
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-angel-card to-transparent" />
                  </div>

                  {/* Content */}
                  <div className="p-4 text-center">
                    <h3 className="font-display text-2xl font-bold text-angel-text mb-1">
                      {coin.amount}
                    </h3>
                    <p className="text-angel-muted text-sm mb-3">Coins</p>
                    <p className="font-pixel text-xl text-angel-accent">{coin.price}</p>
                  </div>

                  {/* Hover overlay */}
                  <div className="absolute inset-0 bg-angel-accent/5 opacity-0 hover:opacity-100 transition-opacity duration-300" />
                </div>
              ))}
            </div>

            {/* CTA */}
            <div 
              className={`mt-12 text-center transition-all duration-700 delay-500 ${
                isVisible['coins'] ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
              }`}
            >
              <a 
                href="https://discord.gg/y4HZq97hgW"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 text-angel-accent hover:underline"
              >
                <MessageCircle className="w-5 h-5" />
                Need custom amounts? Contact us on Discord
              </a>
            </div>
          </div>
        </section>

        {/* Keys Section */}
        <section 
          id="keys" 
          className="min-h-screen px-4 sm:px-6 lg:px-12 py-20 lg:py-24 relative"
        >
          <div className="absolute inset-0 bg-line-pattern opacity-30" />
          
          <div className="relative z-10 max-w-7xl mx-auto">
            {/* Section Header */}
            <div 
              className={`mb-12 transition-all duration-700 ${
                isVisible['keys'] ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
              }`}
            >
              <div className="flex items-center gap-3 mb-4">
                <Key className="w-6 h-6 text-angel-accent" />
                <span className="font-pixel text-angel-accent text-lg">KEYS</span>
              </div>
              <h2 className="font-display text-3xl lg:text-5xl font-bold mb-4">
                Crate <span className="text-angel-accent">Keys</span>
              </h2>
              <p className="text-angel-muted text-lg max-w-2xl">
                Open crates for gear, cosmetics, and surprises. Each key offers different rewards.
              </p>
            </div>

            {/* Keys Cards */}
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 lg:gap-6">
              {keys.map((key, index) => (
                <div
                  key={key.name}
                  className={`rank-card relative overflow-hidden transition-all duration-500 ${
                    isVisible['keys'] 
                      ? 'opacity-100 translate-y-0' 
                      : 'opacity-0 translate-y-10'
                  }`}
                  style={{ transitionDelay: `${index * 100}ms` }}
                >
                  {/* Image */}
                  <div className="relative h-48 overflow-hidden">
                    <img 
                      src={key.image} 
                      alt={key.name}
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-angel-card to-transparent" />
                  </div>

                  {/* Content */}
                  <div className="p-4">
                    <h3 className="font-display text-xl font-bold text-angel-text mb-1">
                      {key.name}
                    </h3>
                    <p className="font-pixel text-xl text-angel-accent">{key.price}</p>
                  </div>

                  {/* Hover effect */}
                  <div className="absolute inset-0 bg-angel-accent/5 opacity-0 hover:opacity-100 transition-opacity duration-300" />
                </div>
              ))}
            </div>

            {/* CTA */}
            <div 
              className={`mt-12 text-center transition-all duration-700 delay-500 ${
                isVisible['keys'] ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
              }`}
            >
              <a 
                href="https://discord.gg/y4HZq97hgW"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 text-angel-accent hover:underline"
              >
                <ShoppingCart className="w-5 h-5" />
                View drop tables on Discord
              </a>
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section 
          id="cta" 
          className="min-h-[60vh] px-4 sm:px-6 lg:px-12 py-20 lg:py-24 relative flex items-center"
        >
          <div className="absolute inset-0 bg-gradient-to-b from-angel-dark via-angel-card to-angel-dark" />
          
          <div className="relative z-10 max-w-4xl mx-auto text-center">
            <div 
              className={`transition-all duration-700 ${
                isVisible['cta'] ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
              }`}
            >
              {/* Icon */}
              <div className="w-20 h-20 bg-angel-accent/10 rounded-2xl flex items-center justify-center mx-auto mb-8">
                <MessageCircle className="w-10 h-10 text-angel-accent" />
              </div>

              {/* Title */}
              <h2 className="font-display text-3xl lg:text-5xl font-bold mb-6">
                Ready to <span className="text-angel-accent">Upgrade?</span>
              </h2>

              {/* Description */}
              <p className="text-angel-muted text-lg mb-8 max-w-2xl mx-auto">
                If you want to buy anything, join our Discord server and create a ticket. 
                Our team will help you with your purchase.
              </p>

              {/* CTA Button */}
              <a
                href="https://discord.gg/y4HZq97hgW"
                target="_blank"
                rel="noopener noreferrer"
                className="btn-primary inline-flex items-center gap-3 text-lg px-8 py-4"
              >
                <MessageCircle className="w-6 h-6" />
                Join Discord Server
                <ChevronRight className="w-5 h-5" />
              </a>

              {/* Features */}
              <div className="mt-12 grid grid-cols-2 md:grid-cols-4 gap-6">
                {[
                  { icon: <Zap className="w-5 h-5" />, text: 'Instant Delivery' },
                  { icon: <Shield className="w-5 h-5" />, text: 'Secure Payment' },
                  { icon: <Headphones className="w-5 h-5" />, text: '24/7 Support' },
                  { icon: <Ban className="w-5 h-5" />, text: 'No Pay-to-Win' },
                ].map((feature, index) => (
                  <div 
                    key={index}
                    className="flex items-center justify-center gap-2 text-angel-muted"
                  >
                    <span className="text-angel-accent">{feature.icon}</span>
                    <span className="text-sm">{feature.text}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* Footer */}
        <footer className="px-4 sm:px-6 lg:px-12 py-8 border-t border-white/5">
          <div className="max-w-7xl mx-auto">
            <div className="flex flex-col md:flex-row items-center justify-between gap-4">
              {/* Logo */}
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-lg bg-angel-accent flex items-center justify-center">
                  <Crown className="w-4 h-4 text-angel-dark" />
                </div>
                <span className="font-display font-bold text-angel-text">Angel Store</span>
              </div>

              {/* Copyright */}
              <p className="text-angel-muted text-sm text-center">
                © 2026 Angel Store. Not affiliated with Mojang/Microsoft.
              </p>

              {/* Links */}
              <div className="flex items-center gap-4">
                <a 
                  href="https://discord.gg/y4HZq97hgW"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-angel-muted hover:text-angel-text transition-colors"
                >
                  <MessageCircle className="w-5 h-5" />
                </a>
              </div>
            </div>
          </div>
        </footer>
      </main>

      {/* Rank Modal */}
      <RankModal 
        rank={selectedRank}
        isOpen={isModalOpen}
        onClose={closeRankModal}
      />

      {/* Mobile bottom padding */}
      <div className="h-16 lg:hidden" />
    </div>
  );
}

export default App;
