import React, { useEffect } from 'react';
import { X } from 'lucide-react';
import { MinecraftText } from './MinecraftText';

interface RankData {
  name: string;
  price: string;
  color: string;
  image?: string;
}

interface RankInfoWithContent {
  name: string;
  price: string;
  color: string;
  content: string;
}

interface RankModalProps {
  rank: RankData | null;
  isOpen: boolean;
  onClose: () => void;
}

const rankData: Record<string, RankInfoWithContent> = {
  'PRO': {
    name: 'PRO',
    price: '19Rs',
    color: '#FF5555',
    content: `§cPRO Rank
§7Donator Rank

§eRank Perks:
§f➤ 2x Lifesteal XP Multiplier
§f➤ Pro Kit Access
§f➤ 3x Backpack Rows
§f➤ 4x Homes
§f➤ 3 Concurrent Auctions
§f➤ 8 Coins Daily Reward

§a/craft §7command
§a/recipe §7command
§a/disposal §7command
§a/near §7command

§cCLICK TO GO TO SHOP`
  },
  'MVP': {
    name: 'MVP',
    price: '29Rs',
    color: '#55FFFF',
    content: `§bMVP Rank
§7Donator Rank

§eRank Perks:
§f➤ 2x Lifesteal XP Multiplier
§f➤ MVP Kit Access
§f➤ 4x Backpack Rows
§f➤ 5x Homes
§f➤ 4 Concurrent Auctions
§f➤ 10 Coins Daily Reward

§a/craft §7command
§a/recipe §7command
§a/disposal §7command
§a/near §7command

§bCLICK TO GO TO SHOP`
  },
  'VIP': {
    name: 'VIP',
    price: '69Rs',
    color: '#55FF55',
    content: `§aVIP Rank
§7Donator Rank

§eRank Perks:
§f➤ 2x Lifesteal XP Multiplier
§f➤ VIP Kit Access
§f➤ 2x Backpack Rows
§f➤ 3x Homes
§f➤ 2 Concurrent Auctions
§f➤ 5 Coins Daily Reward

§a/craft §7command
§a/recipe §7command

§aCLICK TO GO TO SHOP`
  },
  'ELITE': {
    name: 'ELITE',
    price: '99Rs',
    color: '#FF55FF',
    content: `§dELITE Rank
§7Donator Rank

§eRank Perks:
§f➤ 2x Lifesteal XP Multiplier
§f➤ Elite Kit Access
§f➤ 5x Backpack Rows
§f➤ 6x Homes
§f➤ 5 Concurrent Auctions
§f➤ 12 Coins Daily Reward

§a/craft §7command
§a/recipe §7command
§a/disposal §7command
§a/near §7command

§dCLICK TO GO TO SHOP`
  },
  'IMMORTAL': {
    name: 'IMMORTAL',
    price: '149Rs',
    color: '#AA00AA',
    content: `§5IMMORTAL Rank
§7Donator Rank

§eRank Perks:
§f➤ 2x Lifesteal XP Multiplier
§f➤ Immortal Kit Access
§f➤ 6x Backpack Rows
§f➤ 7x Homes
§f➤ 6 Concurrent Auctions
§f➤ 15 Coins Daily Reward

§a/craft §7command
§a/recipe §7command
§a/disposal §7command
§a/near §7command
§a/hat §7command
§a/feed §7command

§5CLICK TO GO TO SHOP`
  }
};

export const RankModal: React.FC<RankModalProps> = ({ rank, isOpen, onClose }) => {
  useEffect(() => {
    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    
    if (isOpen) {
      document.addEventListener('keydown', handleEscape);
      document.body.style.overflow = 'hidden';
    }
    
    return () => {
      document.removeEventListener('keydown', handleEscape);
      document.body.style.overflow = 'unset';
    };
  }, [isOpen, onClose]);

  if (!isOpen || !rank) return null;

  const rankInfo = rankData[rank.name] || rank;

  return (
    <div 
      className="fixed inset-0 z-[200] flex items-center justify-center p-4"
      onClick={onClose}
    >
      {/* Backdrop */}
      <div className="absolute inset-0 bg-black/80 backdrop-blur-sm" />
      
      {/* Modal */}
      <div 
        className="relative w-full max-w-lg animate-in fade-in zoom-in-95 duration-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Pixel border effect */}
        <div 
          className="relative bg-angel-card border-2 p-6 rounded-xl"
          style={{ 
            borderColor: rankInfo.color,
            boxShadow: `0 0 40px ${rankInfo.color}30, inset 0 0 40px ${rankInfo.color}10`
          }}
        >
          {/* Close button */}
          <button
            onClick={onClose}
            className="absolute top-4 right-4 p-2 rounded-lg bg-white/5 hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5 text-angel-muted" />
          </button>

          {/* Header */}
          <div className="mb-6 pr-10">
            <h2 
              className="font-display text-3xl font-bold"
              style={{ color: rankInfo.color }}
            >
              {rankInfo.name} Rank
            </h2>
            <p className="font-pixel text-xl text-angel-muted mt-1">
              {rankInfo.price}
            </p>
          </div>

          {/* Content */}
          <div className="bg-black/40 rounded-lg p-4 font-mono text-sm leading-relaxed overflow-auto max-h-[60vh]">
            <MinecraftText text={rankInfo.content} />
          </div>

          {/* CTA Button */}
          <a
            href="https://discord.gg/y4HZq97hgW"
            target="_blank"
            rel="noopener noreferrer"
            className="mt-6 w-full btn-primary flex items-center justify-center gap-2"
            style={{ backgroundColor: rankInfo.color }}
          >
            <span>Go to Shop</span>
          </a>
        </div>
      </div>
    </div>
  );
};

export default RankModal;
