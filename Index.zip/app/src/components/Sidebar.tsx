import React, { useState, useEffect } from 'react';
import { Home, Crown, Coins, Key, MessageCircle } from 'lucide-react';

interface SidebarProps {
  activeSection: string;
}

interface NavItem {
  id: string;
  label: string;
  icon: React.ReactNode;
  href: string;
  external?: boolean;
}

const navItems: NavItem[] = [
  { id: 'home', label: 'Home', icon: <Home className="w-5 h-5" />, href: '#home' },
  { id: 'ranks', label: 'Ranks', icon: <Crown className="w-5 h-5" />, href: '#ranks' },
  { id: 'coins', label: 'Coins', icon: <Coins className="w-5 h-5" />, href: '#coins' },
  { id: 'keys', label: 'Keys', icon: <Key className="w-5 h-5" />, href: '#keys' },
  { id: 'discord', label: 'Discord', icon: <MessageCircle className="w-5 h-5" />, href: 'https://discord.gg/y4HZq97hgW', external: true },
];

export const Sidebar: React.FC<SidebarProps> = ({ activeSection }) => {
  const [isMobile, setIsMobile] = useState(false);

  useEffect(() => {
    const checkMobile = () => {
      setIsMobile(window.innerWidth < 1024);
    };
    
    checkMobile();
    window.addEventListener('resize', checkMobile);
    return () => window.removeEventListener('resize', checkMobile);
  }, []);

  const handleClick = (e: React.MouseEvent, item: NavItem) => {
    if (item.external) {
      e.preventDefault();
      window.open(item.href, '_blank', 'noopener,noreferrer');
    } else {
      e.preventDefault();
      const element = document.querySelector(item.href);
      if (element) {
        element.scrollIntoView({ behavior: 'smooth' });
      }
    }
  };

  // Mobile bottom nav
  if (isMobile) {
    return (
      <nav className="fixed bottom-0 left-0 right-0 z-[100] bg-angel-dark/95 backdrop-blur-lg border-t border-white/5">
        <div className="flex items-center justify-around py-3 px-2">
          {navItems.map((item) => {
            const isActive = activeSection === item.id;
            return (
              <a
                key={item.id}
                href={item.href}
                onClick={(e) => handleClick(e, item)}
                className={`flex flex-col items-center gap-1 px-3 py-1 rounded-lg transition-all duration-200 ${
                  isActive 
                    ? 'text-angel-accent' 
                    : 'text-angel-muted hover:text-angel-text'
                }`}
                target={item.external ? '_blank' : undefined}
                rel={item.external ? 'noopener noreferrer' : undefined}
              >
                {item.icon}
                <span className="text-[10px] font-medium">{item.label}</span>
              </a>
            );
          })}
        </div>
      </nav>
    );
  }

  // Desktop sidebar
  return (
    <aside className="fixed left-0 top-0 w-[260px] h-screen bg-angel-dark border-r border-white/5 z-[100] flex flex-col">
      {/* Logo */}
      <div className="p-6 border-b border-white/5">
        <a href="#home" className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-angel-accent flex items-center justify-center">
            <Crown className="w-5 h-5 text-angel-dark" />
          </div>
          <div>
            <h1 className="font-display font-bold text-xl text-angel-text">Angel Store</h1>
            <p className="font-pixel text-xs text-angel-muted">Premium Upgrades</p>
          </div>
        </a>
      </div>

      {/* Navigation */}
      <nav className="flex-1 py-6 px-4">
        <ul className="space-y-2">
          {navItems.map((item) => {
            const isActive = activeSection === item.id;
            return (
              <li key={item.id}>
                <a
                  href={item.href}
                  onClick={(e) => handleClick(e, item)}
                  className={`flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 ${
                    isActive
                      ? 'bg-angel-accent/10 text-angel-accent sidebar-active'
                      : 'text-angel-muted hover:text-angel-text hover:bg-white/5'
                  }`}
                  target={item.external ? '_blank' : undefined}
                  rel={item.external ? 'noopener noreferrer' : undefined}
                >
                  {item.icon}
                  <span className="font-medium">{item.label}</span>
                  {item.external && (
                    <svg 
                      className="w-4 h-4 ml-auto opacity-50" 
                      fill="none" 
                      viewBox="0 0 24 24" 
                      stroke="currentColor"
                    >
                      <path 
                        strokeLinecap="round" 
                        strokeLinejoin="round" 
                        strokeWidth={2} 
                        d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" 
                      />
                    </svg>
                  )}
                </a>
              </li>
            );
          })}
        </ul>
      </nav>

      {/* Footer info */}
      <div className="p-4 border-t border-white/5">
        <div className="bg-angel-card rounded-lg p-4">
          <p className="text-xs text-angel-muted mb-2">Need help?</p>
          <a 
            href="https://discord.gg/y4HZq97hgW"
            target="_blank"
            rel="noopener noreferrer"
            className="text-sm text-angel-accent hover:underline flex items-center gap-2"
          >
            <MessageCircle className="w-4 h-4" />
            Join Discord
          </a>
        </div>
      </div>
    </aside>
  );
};

export default Sidebar;
