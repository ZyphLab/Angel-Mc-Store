import React from 'react';

interface MinecraftTextProps {
  text: string;
  className?: string;
}

const minecraftColorToClass: Record<string, string> = {
  '§0': 'text-mc-black',
  '§1': 'text-mc-dark-blue',
  '§2': 'text-mc-dark-green',
  '§3': 'text-mc-dark-aqua',
  '§4': 'text-mc-dark-red',
  '§5': 'text-mc-dark-purple',
  '§6': 'text-mc-gold',
  '§7': 'text-mc-gray',
  '§8': 'text-mc-dark-gray',
  '§9': 'text-mc-blue',
  '§a': 'text-mc-green',
  '§b': 'text-mc-aqua',
  '§c': 'text-mc-red',
  '§d': 'text-mc-light-purple',
  '§e': 'text-mc-yellow',
  '§f': 'text-mc-white',
};

export const MinecraftText: React.FC<MinecraftTextProps> = ({ text, className = '' }) => {
  const parseText = (input: string): React.ReactNode[] => {
    const parts: React.ReactNode[] = [];
    let currentText = '';
    let currentColor = 'text-mc-white';
    let i = 0;

    while (i < input.length) {
      if (input[i] === '§' && i + 1 < input.length) {
        // Push current text with current color
        if (currentText) {
          parts.push(
            <span key={parts.length} className={currentColor}>
              {currentText}
            </span>
          );
          currentText = '';
        }
        // Update color
        const colorCode = '§' + input[i + 1];
        currentColor = minecraftColorToClass[colorCode] || 'text-mc-white';
        i += 2;
      } else {
        currentText += input[i];
        i++;
      }
    }

    // Push remaining text
    if (currentText) {
      parts.push(
        <span key={parts.length} className={currentColor}>
          {currentText}
        </span>
      );
    }

    return parts;
  };

  return (
    <span className={`font-mono whitespace-pre-wrap ${className}`}>
      {parseText(text)}
    </span>
  );
};

export default MinecraftText;
